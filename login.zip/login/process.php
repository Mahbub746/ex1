<?php 
if(isset($_REQUEST['email']) && isset($_REQUEST['password']))
{
	$email=$_REQUEST['email'];
$password=$_REQUEST['password'];
	if( $obj->getByCondituion("users","*","email='$email'
&&password='$password'")!=false){
		session_start();
		$users=$obj->getByCondituion("users","*","email='$email'&& password='$password'");
		$_SESSION['name']=$user['name'];
		header ("location:b.php");
	}
}
 ?> 

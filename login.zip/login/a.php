<?php 
 include "db.php";
 include "process.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<title>Document</title>
	<!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
</head>
<body >

	<div class="container">
    <div clas="row">
	<div class="col-md-4"></div>
	<div class="col-md-4">
<main class="form-signin">
	
  <form action="a.php" method="POST">
    

    <h1 class="h3 mb-3 fw-normal">Please sign in</h1>
    
    <label for="inputEmail" class="visually-hidden">Email address</label>
    <input type="email" id="inputEmail" class="form-control" name="email" placeholder="Email address" required autofocus><br> 
    
    <input type="password" id="inputPassword" name="password"class=form-control" placeholder="Password" required>
    <div class="checkbox mb-3">
      <label>
        <input type="checkbox" value="remember-me"> Remember me
      </label>
  </div>
    
    <button class="w-100 btn btn-lg btn-primary" type="submit">Sign in</button>
    <p class="mt-5 mb-3 text-muted">&copy; 2017–2021</p>
  </form>
</main>
 
</div>
<div class="col-md-4"></div>
 </div>
</div>




    
  </body>
  </html>
